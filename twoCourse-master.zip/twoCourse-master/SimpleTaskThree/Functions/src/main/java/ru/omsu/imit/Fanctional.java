package ru.omsu.imit;

public interface Fanctional<T extends Function> {
    double decideFanctional(T fun,double a,double b);
}
