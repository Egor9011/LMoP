package ru.omsu.imit;

public interface Function {
    double decideFunction(double x);
    double getBorderA();
    double getBorderB();
}
